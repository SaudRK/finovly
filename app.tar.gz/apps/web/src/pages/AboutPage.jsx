
import React from 'react';
import { Helmet } from 'react-helmet';
import Header from '@/components/Header';
import Footer from '@/components/Footer';

function AboutPage() {
  return (
    <>
      <Helmet>
        <title>About Us | Finovly</title>
        <meta name="description" content="Learn about Finovly's mission to help Americans make confident financial decisions." />
      </Helmet>

      <div className="min-h-screen flex flex-col bg-white">
        <Header />

        <main className="flex-1 py-20 px-4">
          <div className="max-w-3xl mx-auto">
            <h1 className="text-[44px] font-extrabold text-[#1B3E6F] mb-6 text-center">About Finovly</h1>
            
            <p className="text-[20px] text-[#5285C9] mb-16 leading-relaxed text-center font-medium">
              We help Americans make confident financial decisions with free, unbiased information, calculators, and expert guides.
            </p>

            <div className="space-y-12 text-[#2A3F5F] text-[16px] leading-relaxed">
              <section>
                <h2 className="text-[28px] font-bold text-[#1B3E6F] mb-5">Our Mission</h2>
                <p>
                  Personal finance shouldn't be complicated. Our mission is to demystify money management by providing clear, accurate, and easy-to-use tools that empower you to take control of your financial future.
                </p>
              </section>

              <section>
                <h2 className="text-[28px] font-bold text-[#1B3E6F] mb-5">Editorial Standards</h2>
                <p>
                  Trust is our most valuable asset. Our editorial team operates independently from our business operations. Every article, review, and calculator is rigorously fact-checked and updated regularly to ensure accuracy. We do not let advertiser relationships dictate our recommendations.
                </p>
              </section>

              <section>
                <h2 className="text-[28px] font-bold text-[#1B3E6F] mb-5">How We Make Money</h2>
                <p className="mb-4">
                  Finovly is free for everyone to use. To keep the lights on, we make money through the following way:
                </p>
                <ul className="list-disc pl-6 space-y-3 marker:text-[#3260A8]">
                  <li><strong className="text-[#1B3E6F]">Affiliate Partnerships:</strong> If you click a link to a partner's site and open an account or buy a product, we may receive a commission. These links are clearly marked with an "Advertiser Disclosure" label.</li>
                </ul>
              </section>
            </div>
          </div>
        </main>

        <Footer />
      </div>
    </>
  );
}

export default AboutPage;
