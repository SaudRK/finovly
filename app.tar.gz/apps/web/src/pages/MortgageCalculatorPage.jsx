
import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import { ArrowLeft, Home, DollarSign, Percent, Calendar } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card.jsx';
import { Label } from '@/components/ui/label.jsx';
import { Input } from '@/components/ui/input.jsx';
import { Button } from '@/components/ui/button.jsx';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';

function MortgageCalculatorPage() {
  const [homePrice, setHomePrice] = useState('350000');
  const [downPayment, setDownPayment] = useState('70000');
  const [interestRate, setInterestRate] = useState('6.5');
  const [loanTerm, setLoanTerm] = useState('30');
  const [result, setResult] = useState(null);

  const calculateMortgage = () => {
    const p = parseFloat(homePrice) || 0;
    const dp = parseFloat(downPayment) || 0;
    const r = parseFloat(interestRate) || 0;
    const t = parseInt(loanTerm) || 0;

    const principal = p - dp;
    
    if (principal <= 0 || r <= 0 || t <= 0) {
      setResult({ monthlyPayment: 0, totalPayment: 0, totalInterest: 0, principal });
      return;
    }

    const monthlyRate = r / 100 / 12;
    const numberOfPayments = t * 12;
    
    const monthlyPayment = principal * (monthlyRate * Math.pow(1 + monthlyRate, numberOfPayments)) / (Math.pow(1 + monthlyRate, numberOfPayments) - 1);
    const totalPayment = monthlyPayment * numberOfPayments;
    const totalInterest = totalPayment - principal;

    setResult({
      monthlyPayment,
      totalPayment,
      totalInterest,
      principal
    });
  };

  const formatCurrency = (val) => {
    return new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(val);
  };

  return (
    <>
      <Helmet>
        <title>Mortgage Payment Calculator | Finovly</title>
        <meta name="description" content="Calculate your estimated monthly mortgage payment, including total interest and principal over the life of the loan." />
      </Helmet>

      <div className="min-h-screen flex flex-col bg-[#F0F5FC]">
        <Header />

        <main className="flex-1 py-12 px-4">
          <div className="max-w-4xl mx-auto">
            <Link to="/calculators" className="inline-flex items-center text-[#3260A8] font-medium hover:underline mb-8">
              <ArrowLeft className="w-4 h-4 mr-2" /> Back to Calculators
            </Link>

            <div className="mb-10">
              <h1 className="text-[36px] md:text-[44px] font-extrabold text-[#1B3E6F] mb-4 tracking-tight">
                Mortgage Calculator
              </h1>
              <p className="text-xl text-[#5285C9] leading-relaxed">
                Estimate your monthly house payments and see how much interest you'll pay over the life of your loan.
              </p>
            </div>

            <Card className="shadow-lg border-border mb-16">
              <CardHeader className="bg-slate-50 border-b border-border rounded-t-xl pb-6">
                <CardTitle className="text-2xl font-bold text-[#1B3E6F] flex items-center gap-2">
                  <Home className="w-6 h-6 text-primary" /> Mortgage Details
                </CardTitle>
                <CardDescription className="text-[15px]">
                  Enter the details of your home purchase to calculate payments.
                </CardDescription>
              </CardHeader>
              <CardContent className="p-6 sm:p-8">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
                  <div className="space-y-2">
                    <Label htmlFor="homePrice" className="text-[15px] font-semibold text-[#1B3E6F]">Home Price</Label>
                    <div className="relative">
                      <DollarSign className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                      <Input
                        id="homePrice"
                        type="number"
                        value={homePrice}
                        onChange={(e) => setHomePrice(e.target.value)}
                        className="pl-10 h-12 text-lg text-gray-900 border-[#D6E4F5]"
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="downPayment" className="text-[15px] font-semibold text-[#1B3E6F]">Down Payment</Label>
                    <div className="relative">
                      <DollarSign className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                      <Input
                        id="downPayment"
                        type="number"
                        value={downPayment}
                        onChange={(e) => setDownPayment(e.target.value)}
                        className="pl-10 h-12 text-lg text-gray-900 border-[#D6E4F5]"
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="interestRate" className="text-[15px] font-semibold text-[#1B3E6F]">Interest Rate (%)</Label>
                    <div className="relative">
                      <Percent className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                      <Input
                        id="interestRate"
                        type="number"
                        step="0.1"
                        value={interestRate}
                        onChange={(e) => setInterestRate(e.target.value)}
                        className="pl-10 h-12 text-lg text-gray-900 border-[#D6E4F5]"
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="loanTerm" className="text-[15px] font-semibold text-[#1B3E6F]">Loan Term (Years)</Label>
                    <div className="relative">
                      <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                      <Input
                        id="loanTerm"
                        type="number"
                        value={loanTerm}
                        onChange={(e) => setLoanTerm(e.target.value)}
                        className="pl-10 h-12 text-lg text-gray-900 border-[#D6E4F5]"
                      />
                    </div>
                  </div>
                </div>

                <Button 
                  onClick={calculateMortgage} 
                  className="w-full btn-primary h-14 text-lg font-bold"
                >
                  Calculate Payment
                </Button>

                {result && (
                  <div className="mt-8 bg-[#EEF4FF] rounded-xl p-6 border border-[#D6E4F5]">
                    <h3 className="text-center text-[#5285C9] font-bold uppercase tracking-wider text-sm mb-2">Estimated Monthly Payment (P&I)</h3>
                    <div className="text-center text-[48px] font-extrabold text-[#1B3E6F] mb-8 leading-none">
                      {formatCurrency(result.monthlyPayment)}
                    </div>
                    
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 border-t border-[#D6E4F5] pt-6">
                      <div className="text-center">
                        <div className="text-[#5285C9] text-sm font-medium mb-1">Principal Amount</div>
                        <div className="text-[#1B3E6F] font-bold text-xl">{formatCurrency(result.principal)}</div>
                      </div>
                      <div className="text-center">
                        <div className="text-[#5285C9] text-sm font-medium mb-1">Total Interest Paid</div>
                        <div className="text-[#1B3E6F] font-bold text-xl">{formatCurrency(result.totalInterest)}</div>
                      </div>
                      <div className="text-center">
                        <div className="text-[#5285C9] text-sm font-medium mb-1">Total Cost of Loan</div>
                        <div className="text-[#1B3E6F] font-bold text-xl">{formatCurrency(result.totalPayment)}</div>
                      </div>
                    </div>
                    <p className="text-xs text-[#5285C9] text-center mt-6">
                      *Note: This calculation covers Principal and Interest (P&I) only. It does not include property taxes, homeowners insurance, or PMI.
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>

            <div className="bg-white rounded-2xl p-8 border border-border shadow-sm">
              <h2 className="text-[24px] font-bold text-[#1B3E6F] mb-6">Understanding Your Mortgage</h2>
              <div className="space-y-4 text-[#2A3F5F] leading-relaxed">
                <p>
                  <strong>Principal:</strong> The actual amount of money you borrowed to buy the home (Home Price minus Down Payment).
                </p>
                <p>
                  <strong>Interest:</strong> The fee the lender charges you for borrowing the money. Over a 30-year loan, the total interest can sometimes equal or exceed the original loan amount.
                </p>
                <p>
                  <strong>Down Payment:</strong> The upfront cash you pay toward the home purchase. A 20% down payment is traditionally recommended to avoid Private Mortgage Insurance (PMI), but many loans allow 3-5% down.
                </p>
              </div>
            </div>
          </div>
        </main>

        <Footer />
      </div>
    </>
  );
}

export default MortgageCalculatorPage;
