
import React from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Calculator, Home, Scale, Activity, DollarSign, ChevronRight } from 'lucide-react';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';
import TrustBar from '@/components/TrustBar.jsx';
import CalculatorCard from '@/components/CalculatorCard.jsx';
import BlogCard from '@/components/BlogCard.jsx';
import { blogPosts } from '@/data/blogPosts.js';

function HomePage() {
  const calculators = [
    { icon: Calculator, title: 'Compound Interest', description: 'See how your money grows over time with the power of compounding.', link: '/calculators' },
    { icon: Home, title: 'Mortgage Payment', description: 'Calculate your monthly mortgage payments including taxes and insurance.', link: '/calculators' },
    { icon: Scale, title: 'Loan Comparison', description: 'Compare different loan options to find the best rates and terms.', link: '/calculators' },
    { icon: Activity, title: 'BMI Calculator', description: 'Check your Body Mass Index and understand your health metrics.', link: '/calculators' },
    { icon: Activity, title: 'Calorie Calculator', description: 'Determine your daily caloric needs for weight loss or maintenance.', link: '/calculators' },
    { icon: DollarSign, title: 'Salary & Tax', description: 'Estimate your take-home pay after federal and state taxes.', link: '/calculators' },
  ];

  // Get the 3 most recent posts
  const recentPosts = blogPosts.slice(0, 3);

  return (
    <>
      <Helmet>
        <title>Finovly — Free Financial Calculators & Unbiased Money Advice</title>
        <meta name="description" content="Free compound interest calculators, mortgage tools, credit card comparisons, and expert personal finance guides to help you make smarter money decisions." />
      </Helmet>

      <div className="min-h-screen flex flex-col bg-[#F0F5FC]">
        <Header />

        <main className="flex-1">
          {/* Hero Section */}
          <section className="relative min-h-[calc(100dvh-5rem)] flex items-center justify-center px-4 border-b border-border text-center py-20 overflow-hidden">
            {/* Background Image */}
            <div 
              className="absolute inset-0 bg-cover bg-center bg-no-repeat"
              style={{ backgroundImage: 'url("https://horizons-cdn.hostinger.com/ddb1bf61-ad7f-403c-98d4-7d62beea60b8/ab5f52a739e78d7524591a1840e8fbef.jpg")' }}
              aria-hidden="true"
            />
            
            {/* Dark Overlay for text contrast */}
            <div className="absolute inset-0 bg-slate-950/50" />
            
            <div className="relative z-10 max-w-4xl mx-auto">
              <motion.h1 
                initial={{ opacity: 0, y: 15 }} 
                animate={{ opacity: 1, y: 0 }} 
                transition={{ duration: 0.5 }}
                className="text-[44px] md:text-[64px] font-extrabold text-white leading-[1.1] mb-6 tracking-tight drop-shadow-sm"
                style={{ textWrap: 'balance' }}
              >
                Make Smarter Financial Decisions
              </motion.h1>
              <motion.p 
                initial={{ opacity: 0, y: 15 }} 
                animate={{ opacity: 1, y: 0 }} 
                transition={{ duration: 0.5, delay: 0.1 }}
                className="text-xl md:text-[22px] text-slate-100 mb-10 max-w-2xl mx-auto leading-relaxed drop-shadow-sm"
              >
                Free tools, unbiased comparisons, and expert guides — all in one place.
              </motion.p>
              <motion.div
                initial={{ opacity: 0, y: 15 }} 
                animate={{ opacity: 1, y: 0 }} 
                transition={{ duration: 0.5, delay: 0.2 }}
              >
                <Link to="/calculators" className="btn-primary inline-flex items-center justify-center px-8 py-4 text-[17px] shadow-lg">
                  Explore Free Tools <ChevronRight className="w-5 h-5 ml-2" />
                </Link>
              </motion.div>
            </div>
          </section>

          <TrustBar />

          {/* Featured Calculators */}
          <section className="py-16 px-4">
            <div className="max-w-7xl mx-auto">
              <div className="flex flex-col md:flex-row justify-between items-baseline mb-10">
                <div>
                  <h2 className="text-[32px] font-bold text-[#1B3E6F] mb-3">Featured Calculators</h2>
                  <p className="text-[#5285C9] text-lg">Crunch the numbers before you make a move.</p>
                </div>
                <Link to="/calculators" className="text-[#3260A8] font-semibold hover:underline mt-4 md:mt-0 flex items-center">
                  See all calculators <ChevronRight className="w-4 h-4 ml-1" />
                </Link>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {calculators.map((calc, idx) => (
                  <CalculatorCard key={idx} {...calc} />
                ))}
              </div>
            </div>
          </section>

          {/* Latest Articles */}
          <section className="py-20 px-4">
            <div className="max-w-7xl mx-auto">
              <div className="flex flex-col md:flex-row justify-between items-baseline mb-10">
                <div>
                  <h2 className="text-[32px] font-bold text-[#1B3E6F] mb-3">Latest Financial Guides</h2>
                  <p className="text-[#5285C9] text-lg">Expert advice to help you grow your wealth.</p>
                </div>
                <Link to="/blog" className="text-[#3260A8] font-semibold hover:underline mt-4 md:mt-0 flex items-center">
                  Read more articles <ChevronRight className="w-4 h-4 ml-1" />
                </Link>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {recentPosts.map((post) => (
                  <BlogCard key={post.id} post={post} />
                ))}
              </div>
            </div>
          </section>
        </main>

        <Footer />
      </div>
    </>
  );
}

export default HomePage;
