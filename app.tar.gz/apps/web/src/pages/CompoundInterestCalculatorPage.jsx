
import React from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import { ArrowLeft, Info } from 'lucide-react';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';
import CompoundInterestCalculator from '@/components/CompoundInterestCalculator.jsx';

function CompoundInterestCalculatorPage() {
  return (
    <>
      <Helmet>
        <title>Free Compound Interest Calculator | Finovly</title>
        <meta name="description" content="Calculate how your investments can grow over time with our free compound interest calculator. See the power of compounding." />
      </Helmet>

      <div className="min-h-screen flex flex-col bg-[#F0F5FC]">
        <Header />

        <main className="flex-1 py-12 px-4">
          <div className="max-w-6xl mx-auto">
            <Link to="/calculators" className="inline-flex items-center text-[#3260A8] font-medium hover:underline mb-8">
              <ArrowLeft className="w-4 h-4 mr-2" /> Back to Calculators
            </Link>

            <div className="mb-10">
              <h1 className="text-[36px] md:text-[44px] font-extrabold text-[#1B3E6F] mb-4 tracking-tight">
                Compound Interest Calculator
              </h1>
              <p className="text-xl text-[#5285C9] max-w-3xl leading-relaxed">
                Discover how small, consistent investments can turn into significant wealth over time through the power of compound interest.
              </p>
            </div>

            <CompoundInterestCalculator />

            <div className="mt-16 bg-white rounded-2xl p-8 border border-border shadow-sm">
              <h2 className="text-[24px] font-bold text-[#1B3E6F] mb-6">How to Use This Calculator</h2>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8 text-[#2A3F5F] leading-relaxed">
                <div>
                  <h3 className="font-semibold text-lg mb-2 flex items-center gap-2">
                    <Info className="w-5 h-5 text-[#3260A8]" /> The Basics
                  </h3>
                  <p className="mb-4">
                    <strong>Initial Investment:</strong> The amount of money you have available to invest right now.
                  </p>
                  <p className="mb-4">
                    <strong>Monthly Contribution:</strong> The amount you plan to add to your investment every month. Consistency is key to building wealth!
                  </p>
                  <p>
                    <strong>Time Period:</strong> How long you plan to leave your money invested. The longer the timeframe, the more powerful compounding becomes.
                  </p>
                </div>
                <div>
                  <h3 className="font-semibold text-lg mb-2 flex items-center gap-2">
                    <Info className="w-5 h-5 text-[#3260A8]" /> Advanced Settings
                  </h3>
                  <p className="mb-4">
                    <strong>Annual Interest Rate:</strong> The expected average annual return on your investment. Historically, the stock market averages around 7-10% per year (before inflation).
                  </p>
                  <p>
                    <strong>Compounding Frequency:</strong> How often interest is calculated and added to your balance. Most savings accounts compound monthly, while some bonds might compound semi-annually.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </main>

        <Footer />
      </div>
    </>
  );
}

export default CompoundInterestCalculatorPage;
