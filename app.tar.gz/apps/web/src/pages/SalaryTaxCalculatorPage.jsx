
import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import { ArrowLeft, DollarSign } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card.jsx';
import { Label } from '@/components/ui/label.jsx';
import { Input } from '@/components/ui/input.jsx';
import { Button } from '@/components/ui/button.jsx';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';

function SalaryTaxCalculatorPage() {
  const [salary, setSalary] = useState('65000');
  const [result, setResult] = useState(null);

  const calculateTaxes = () => {
    const gross = parseFloat(salary) || 0;
    if (gross <= 0) return;

    // Extremely simplified 2024 single filer estimation for demo purposes
    const standardDeduction = 14600;
    let taxableIncome = Math.max(0, gross - standardDeduction);
    let federalTax = 0;

    // Brackets
    const brackets = [
      { limit: 11600, rate: 0.10 },
      { limit: 47150, rate: 0.12 },
      { limit: 100525, rate: 0.22 },
      { limit: 191950, rate: 0.24 },
      { limit: 243725, rate: 0.32 },
      { limit: 609350, rate: 0.35 },
      { limit: Infinity, rate: 0.37 }
    ];

    let previousLimit = 0;
    for (let i = 0; i < brackets.length; i++) {
      if (taxableIncome > previousLimit) {
        const amountInBracket = Math.min(taxableIncome, brackets[i].limit) - previousLimit;
        federalTax += amountInBracket * brackets[i].rate;
        previousLimit = brackets[i].limit;
      } else {
        break;
      }
    }

    // FICA (Social Security 6.2% up to $168,600 + Medicare 1.45%)
    const socialSecurity = Math.min(gross, 168600) * 0.062;
    const medicare = gross * 0.0145;
    const fica = socialSecurity + medicare;

    const totalTax = federalTax + fica;
    const netPay = gross - totalTax;

    setResult({
      gross,
      federalTax,
      fica,
      totalTax,
      netPay,
      monthlyNet: netPay / 12,
      biweeklyNet: netPay / 26
    });
  };

  const formatCurrency = (val) => {
    return new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', maximumFractionDigits: 0 }).format(val);
  };

  return (
    <>
      <Helmet>
        <title>Salary & Income Tax Calculator | Finovly</title>
        <meta name="description" content="Calculate your estimated take-home pay after federal taxes and FICA deductions." />
      </Helmet>

      <div className="min-h-screen flex flex-col bg-[#F0F5FC]">
        <Header />

        <main className="flex-1 py-12 px-4">
          <div className="max-w-4xl mx-auto">
            <Link to="/calculators" className="inline-flex items-center text-[#3260A8] font-medium hover:underline mb-8">
              <ArrowLeft className="w-4 h-4 mr-2" /> Back to Calculators
            </Link>

            <div className="mb-10 text-center">
              <h1 className="text-[36px] md:text-[44px] font-extrabold text-[#1B3E6F] mb-4 tracking-tight">
                Salary & Tax Calculator
              </h1>
              <p className="text-xl text-[#5285C9] leading-relaxed">
                Estimate your take-home pay after federal taxes and payroll deductions.
              </p>
            </div>

            <Card className="shadow-lg border-border mb-16">
              <CardHeader className="bg-slate-50 border-b border-border rounded-t-xl pb-6">
                <CardTitle className="text-2xl font-bold text-[#1B3E6F] flex items-center gap-2">
                  <DollarSign className="w-6 h-6 text-primary" /> Income Details
                </CardTitle>
                <CardDescription className="text-[15px]">
                  Calculations based on 2024 Federal Tax Brackets for Single Filers.
                </CardDescription>
              </CardHeader>
              <CardContent className="p-6 sm:p-8">
                <div className="max-w-md mx-auto mb-8">
                  <div className="space-y-2">
                    <Label className="text-[15px] font-semibold text-[#1B3E6F]">Gross Annual Salary</Label>
                    <div className="relative">
                      <DollarSign className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                      <Input 
                        type="number" 
                        value={salary} 
                        onChange={(e) => setSalary(e.target.value)} 
                        className="pl-10 h-14 text-xl font-medium text-gray-900 border-[#D6E4F5]" 
                      />
                    </div>
                  </div>
                  <Button onClick={calculateTaxes} className="w-full btn-primary h-14 text-lg font-bold mt-6">
                    Calculate Take-Home Pay
                  </Button>
                </div>

                {result && (
                  <div className="mt-10 border-t border-[#D6E4F5] pt-10">
                    <div className="bg-[#1B3E6F] text-white rounded-xl p-8 text-center mb-8 shadow-md">
                      <div className="text-sm font-bold text-[#D6E4F5] uppercase tracking-wide mb-2">Estimated Annual Take-Home</div>
                      <div className="text-[48px] font-extrabold leading-none">{formatCurrency(result.netPay)}</div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                      <div className="bg-slate-50 rounded-xl p-6 border border-border">
                        <h3 className="font-bold text-[#1B3E6F] mb-4 border-b border-border pb-2">Pay Schedule</h3>
                        <div className="space-y-3">
                          <div className="flex justify-between">
                            <span className="text-[#5285C9]">Monthly</span>
                            <span className="font-bold text-[#2A3F5F]">{formatCurrency(result.monthlyNet)}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-[#5285C9]">Bi-weekly</span>
                            <span className="font-bold text-[#2A3F5F]">{formatCurrency(result.biweeklyNet)}</span>
                          </div>
                        </div>
                      </div>

                      <div className="bg-slate-50 rounded-xl p-6 border border-border">
                        <h3 className="font-bold text-[#1B3E6F] mb-4 border-b border-border pb-2">Estimated Taxes</h3>
                        <div className="space-y-3">
                          <div className="flex justify-between">
                            <span className="text-[#5285C9]">Federal Income Tax</span>
                            <span className="font-bold text-destructive">{formatCurrency(result.federalTax)}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-[#5285C9]">FICA (SS & Medicare)</span>
                            <span className="font-bold text-destructive">{formatCurrency(result.fica)}</span>
                          </div>
                          <div className="flex justify-between pt-2 border-t border-border">
                            <span className="font-bold text-[#1B3E6F]">Total Tax</span>
                            <span className="font-bold text-destructive">{formatCurrency(result.totalTax)}</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </main>

        <Footer />
      </div>
    </>
  );
}

export default SalaryTaxCalculatorPage;
