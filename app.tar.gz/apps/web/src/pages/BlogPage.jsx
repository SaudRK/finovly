
import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import { Clock, Calendar, ArrowRight } from 'lucide-react';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';
import BlogCard from '@/components/BlogCard.jsx';
import CategoryTag from '@/components/CategoryTag.jsx';
import { blogPosts } from '@/data/blogPosts.js';

function BlogPage() {
  const [email, setEmail] = useState('');

  // Sort by views to get popular posts
  const sortedByViews = [...blogPosts].sort((a, b) => b.views - a.views);
  const featuredPost = sortedByViews[0];
  const popularPosts = sortedByViews.slice(1, 6);
  
  // Remaining posts for the grid
  const gridPosts = blogPosts.filter(post => post.id !== featuredPost.id);

  const handleSubscribe = (e) => {
    e.preventDefault();
    // Placeholder for actual subscribe logic
    setEmail('');
    alert('Subscribed successfully!');
  };

  return (
    <>
      <Helmet>
        <title>Personal Finance Blog & Guides | Finovly</title>
        <meta name="description" content="Expert articles on investing, budgeting, credit, and retirement to help you master your money." />
      </Helmet>

      <div className="min-h-screen flex flex-col bg-[#F0F5FC]">
        <Header />

        <main className="flex-1 py-12 px-4">
          <div className="max-w-7xl mx-auto">
            
            <div className="mb-12 text-center md:text-left">
              <h1 className="text-[40px] md:text-[48px] font-extrabold text-[#1B3E6F] mb-4 tracking-tight">Financial Guides</h1>
              <p className="text-xl text-[#5285C9] max-w-2xl">
                Expert advice on investing, budgeting, and mastering your money.
              </p>
            </div>

            {/* Featured Hero Section */}
            <Link to={`/blog/${featuredPost.id}`} className="block group mb-16">
              <div className="bg-white border border-[#D6E4F5] rounded-2xl overflow-hidden shadow-sm hover:shadow-md transition-all duration-300 flex flex-col md:flex-row">
                <div className="md:w-3/5 relative h-64 md:h-auto overflow-hidden">
                  <img 
                    src={featuredPost.featuredImage} 
                    alt={featuredPost.title} 
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                  />
                </div>
                <div className="md:w-2/5 p-8 md:p-12 flex flex-col justify-center">
                  <div className="mb-4">
                    <CategoryTag category={featuredPost.category} />
                  </div>
                  <h2 className="text-2xl md:text-3xl font-bold text-[#1B3E6F] mb-4 group-hover:text-[#3260A8] transition-colors leading-snug">
                    {featuredPost.title}
                  </h2>
                  <p className="text-[#5285C9] text-lg mb-6 line-clamp-3">
                    {featuredPost.excerpt}
                  </p>
                  <div className="flex items-center gap-4 text-sm text-[#8FA8C8] font-medium mt-auto">
                    <span className="text-[#2A3F5F] font-bold">{featuredPost.author}</span>
                    <span>•</span>
                    <div className="flex items-center gap-1.5">
                      <Calendar className="w-4 h-4" />
                      <span>{new Date(featuredPost.datePublished).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}</span>
                    </div>
                  </div>
                </div>
              </div>
            </Link>

            <div className="flex flex-col lg:flex-row gap-10">
              {/* Main Content Grid */}
              <div className="lg:w-2/3">
                <h3 className="text-2xl font-bold text-[#1B3E6F] mb-6 border-b border-[#D6E4F5] pb-2">Latest Articles</h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                  {gridPosts.map((post) => (
                    <BlogCard key={post.id} post={post} />
                  ))}
                </div>
              </div>

              {/* Sidebar */}
              <aside className="lg:w-1/3 space-y-8">
                {/* Newsletter Signup */}
                <div className="bg-white border border-[#D6E4F5] rounded-xl p-8 shadow-sm">
                  <h3 className="text-[20px] font-bold text-[#1B3E6F] mb-3">Get Smarter with Money</h3>
                  <p className="text-[15px] text-[#5285C9] mb-6">
                    Join 50,000+ subscribers getting our weekly financial tips and tool updates.
                  </p>
                  <form className="space-y-4" onSubmit={handleSubscribe}>
                    <input 
                      type="email" 
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="Your email address" 
                      className="w-full px-4 py-3 rounded-md border border-[#D6E4F5] bg-white text-[#2A3F5F] placeholder:text-[#8FA8C8] focus:outline-none focus:ring-2 focus:ring-[#3260A8]"
                      required
                    />
                    <button type="submit" className="w-full bg-[#3260A8] text-white hover:bg-[#254A8A] transition-colors font-medium rounded-md py-3 shadow-sm">
                      Subscribe
                    </button>
                  </form>
                </div>

                {/* Most Popular */}
                <div className="bg-white border border-[#D6E4F5] rounded-xl p-8 shadow-sm">
                  <h3 className="text-[20px] font-bold text-[#1B3E6F] mb-6 border-b border-[#D6E4F5] pb-2">Most Popular</h3>
                  <div className="space-y-6">
                    {popularPosts.map((post, index) => (
                      <Link key={post.id} to={`/blog/${post.id}`} className="flex gap-4 group cursor-pointer">
                        <div className="text-3xl font-extrabold text-[#EEF4FF] group-hover:text-[#D6E4F5] transition-colors">
                          0{index + 1}
                        </div>
                        <div>
                          <h4 className="font-bold text-[#2A3F5F] group-hover:text-[#3260A8] transition-colors leading-snug mb-1">
                            {post.title}
                          </h4>
                          <div className="text-xs text-[#8FA8C8] font-medium flex items-center gap-2">
                            <span>{post.readTime}</span>
                          </div>
                        </div>
                      </Link>
                    ))}
                  </div>
                </div>
              </aside>
            </div>
          </div>
        </main>

        <Footer />
      </div>
    </>
  );
}

export default BlogPage;
