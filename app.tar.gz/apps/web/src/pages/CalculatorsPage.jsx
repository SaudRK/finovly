
import React from 'react';
import { Helmet } from 'react-helmet';
import { Calculator, Home, Scale, Activity, DollarSign } from 'lucide-react';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';
import CalculatorCard from '@/components/CalculatorCard.jsx';

function CalculatorsPage() {
  const financeCalculators = [
    { icon: Calculator, title: 'Compound Interest', description: 'See how your money grows over time with the power of compounding.', link: '/calculators/compound-interest' },
    { icon: Home, title: 'Mortgage Payment', description: 'Calculate your monthly mortgage payments including taxes and insurance.', link: '/calculators/mortgage' },
    { icon: Scale, title: 'Loan Comparison', description: 'Compare different loan options to find the best rates and terms.', link: '/calculators/loan-comparison' },
    { icon: Activity, title: 'BMI Calculator', description: 'Check your Body Mass Index and understand your health metrics.', link: '/calculators/bmi' },
    { icon: Activity, title: 'Calorie Calculator', description: 'Determine your daily caloric needs for weight loss or maintenance.', link: '/calculators/calorie' },
    { icon: DollarSign, title: 'Salary & Tax', description: 'Estimate your take-home pay after federal and state taxes.', link: '/calculators/salary-tax' },
  ];

  return (
    <>
      <Helmet>
        <title>Free Financial & Lifestyle Calculators | Finovly</title>
        <meta name="description" content="Access our suite of free calculators for compound interest, mortgages, loans, and health metrics." />
      </Helmet>

      <div className="min-h-screen flex flex-col bg-[#F0F5FC]">
        <Header />

        <main className="flex-1 py-16 px-4">
          <div className="max-w-7xl mx-auto">
            <div className="mb-16">
              <h1 className="text-[40px] font-extrabold text-[#1B3E6F] mb-4">Calculators & Tools</h1>
              <p className="text-xl text-[#5285C9] max-w-3xl">
                Make data-driven decisions with our comprehensive suite of free calculators.
              </p>
            </div>

            <section>
              <h2 className="text-[24px] font-bold text-[#1B3E6F] mb-8 pb-3 border-b border-border">Finance & Lifestyle Calculators</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {financeCalculators.map((calc, idx) => (
                  <CalculatorCard key={idx} {...calc} />
                ))}
              </div>
            </section>
          </div>
        </main>

        <Footer />
      </div>
    </>
  );
}

export default CalculatorsPage;
