
import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import { ArrowLeft, Activity } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card.jsx';
import { Label } from '@/components/ui/label.jsx';
import { Input } from '@/components/ui/input.jsx';
import { Button } from '@/components/ui/button.jsx';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';

function BMICalculatorPage() {
  const [feet, setFeet] = useState('5');
  const [inches, setInches] = useState('9');
  const [weight, setWeight] = useState('160');
  const [result, setResult] = useState(null);

  const calculateBMI = () => {
    const f = parseFloat(feet) || 0;
    const i = parseFloat(inches) || 0;
    const w = parseFloat(weight) || 0;

    if (w <= 0 || (f === 0 && i === 0)) return;

    const heightInInches = (f * 12) + i;
    const bmiValue = (w / (heightInInches * heightInInches)) * 703;
    
    let category = '';
    let colorClass = '';

    if (bmiValue < 18.5) {
      category = 'Underweight';
      colorClass = 'text-blue-500';
    } else if (bmiValue >= 18.5 && bmiValue < 24.9) {
      category = 'Normal weight';
      colorClass = 'text-green-500';
    } else if (bmiValue >= 25 && bmiValue < 29.9) {
      category = 'Overweight';
      colorClass = 'text-orange-500';
    } else {
      category = 'Obese';
      colorClass = 'text-red-500';
    }

    setResult({
      value: bmiValue.toFixed(1),
      category,
      colorClass
    });
  };

  return (
    <>
      <Helmet>
        <title>BMI Calculator | Finovly</title>
        <meta name="description" content="Calculate your Body Mass Index (BMI) easily with our free tool to see if you're in a healthy weight range." />
      </Helmet>

      <div className="min-h-screen flex flex-col bg-[#F0F5FC]">
        <Header />

        <main className="flex-1 py-12 px-4">
          <div className="max-w-3xl mx-auto">
            <Link to="/calculators" className="inline-flex items-center text-[#3260A8] font-medium hover:underline mb-8">
              <ArrowLeft className="w-4 h-4 mr-2" /> Back to Calculators
            </Link>

            <div className="mb-10 text-center">
              <h1 className="text-[36px] md:text-[44px] font-extrabold text-[#1B3E6F] mb-4 tracking-tight">
                BMI Calculator
              </h1>
              <p className="text-xl text-[#5285C9] leading-relaxed">
                A simple tool to measure your body mass index based on height and weight.
              </p>
            </div>

            <Card className="shadow-lg border-border mb-16">
              <CardHeader className="bg-slate-50 border-b border-border rounded-t-xl pb-6">
                <CardTitle className="text-2xl font-bold text-[#1B3E6F] flex items-center gap-2">
                  <Activity className="w-6 h-6 text-primary" /> Enter Your Details
                </CardTitle>
                <CardDescription className="text-[15px]">
                  Use standard measurements (feet, inches, pounds).
                </CardDescription>
              </CardHeader>
              <CardContent className="p-6 sm:p-8">
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 mb-8">
                  <div className="space-y-2">
                    <Label htmlFor="feet" className="text-[15px] font-semibold text-[#1B3E6F]">Height (Feet)</Label>
                    <Input
                      id="feet"
                      type="number"
                      value={feet}
                      onChange={(e) => setFeet(e.target.value)}
                      className="h-12 text-lg text-gray-900 border-[#D6E4F5]"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="inches" className="text-[15px] font-semibold text-[#1B3E6F]">Height (Inches)</Label>
                    <Input
                      id="inches"
                      type="number"
                      value={inches}
                      onChange={(e) => setInches(e.target.value)}
                      className="h-12 text-lg text-gray-900 border-[#D6E4F5]"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="weight" className="text-[15px] font-semibold text-[#1B3E6F]">Weight (lbs)</Label>
                    <Input
                      id="weight"
                      type="number"
                      value={weight}
                      onChange={(e) => setWeight(e.target.value)}
                      className="h-12 text-lg text-gray-900 border-[#D6E4F5]"
                    />
                  </div>
                </div>

                <Button 
                  onClick={calculateBMI} 
                  className="w-full btn-primary h-14 text-lg font-bold"
                >
                  Calculate BMI
                </Button>

                {result && (
                  <div className="mt-8 text-center bg-[#F0F5FC] border border-[#D6E4F5] rounded-xl p-8">
                    <p className="text-[#5285C9] font-semibold uppercase tracking-wider mb-2">Your BMI Is</p>
                    <div className="text-[64px] font-black text-[#1B3E6F] leading-none mb-4">{result.value}</div>
                    <div className={`text-2xl font-bold ${result.colorClass}`}>
                      {result.category}
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </main>

        <Footer />
      </div>
    </>
  );
}

export default BMICalculatorPage;
