
import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import { ArrowLeft, Activity } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card.jsx';
import { Label } from '@/components/ui/label.jsx';
import { Input } from '@/components/ui/input.jsx';
import { Button } from '@/components/ui/button.jsx';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select.jsx';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';

function CalorieCalculatorPage() {
  const [age, setAge] = useState('30');
  const [gender, setGender] = useState('male');
  const [feet, setFeet] = useState('5');
  const [inches, setInches] = useState('10');
  const [weight, setWeight] = useState('170');
  const [activity, setActivity] = useState('1.55');
  const [result, setResult] = useState(null);

  const calculateCalories = () => {
    const a = parseFloat(age) || 0;
    const f = parseFloat(feet) || 0;
    const i = parseFloat(inches) || 0;
    const wLbs = parseFloat(weight) || 0;
    const actMultiplier = parseFloat(activity) || 1.2;

    if (a <= 0 || wLbs <= 0 || (f === 0 && i === 0)) return;

    // Convert to metric for Mifflin-St Jeor
    const weightKg = wLbs * 0.453592;
    const heightCm = ((f * 12) + i) * 2.54;

    let bmr = (10 * weightKg) + (6.25 * heightCm) - (5 * a);
    if (gender === 'male') {
      bmr += 5;
    } else {
      bmr -= 161;
    }

    const maintenance = Math.round(bmr * actMultiplier);

    setResult({
      maintenance,
      loss: maintenance - 500,
      gain: maintenance + 500
    });
  };

  return (
    <>
      <Helmet>
        <title>Daily Calorie Calculator | Finovly</title>
        <meta name="description" content="Calculate how many calories you need to eat daily to maintain, lose, or gain weight." />
      </Helmet>

      <div className="min-h-screen flex flex-col bg-[#F0F5FC]">
        <Header />

        <main className="flex-1 py-12 px-4">
          <div className="max-w-4xl mx-auto">
            <Link to="/calculators" className="inline-flex items-center text-[#3260A8] font-medium hover:underline mb-8">
              <ArrowLeft className="w-4 h-4 mr-2" /> Back to Calculators
            </Link>

            <div className="mb-10 text-center">
              <h1 className="text-[36px] md:text-[44px] font-extrabold text-[#1B3E6F] mb-4 tracking-tight">
                Daily Calorie Calculator
              </h1>
              <p className="text-xl text-[#5285C9] leading-relaxed">
                Find out your daily maintenance calories and targets for your fitness goals.
              </p>
            </div>

            <Card className="shadow-lg border-border mb-16">
              <CardHeader className="bg-slate-50 border-b border-border rounded-t-xl pb-6">
                <CardTitle className="text-2xl font-bold text-[#1B3E6F] flex items-center gap-2">
                  <Activity className="w-6 h-6 text-primary" /> Personal Metrics
                </CardTitle>
                <CardDescription className="text-[15px]">
                  Calculations based on the Mifflin-St Jeor equation.
                </CardDescription>
              </CardHeader>
              <CardContent className="p-6 sm:p-8">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
                  <div className="space-y-2">
                    <Label className="text-[15px] font-semibold text-[#1B3E6F]">Age</Label>
                    <Input type="number" value={age} onChange={(e) => setAge(e.target.value)} className="h-12 text-gray-900 border-[#D6E4F5]" />
                  </div>
                  <div className="space-y-2">
                    <Label className="text-[15px] font-semibold text-[#1B3E6F]">Gender</Label>
                    <Select value={gender} onValueChange={setGender}>
                      <SelectTrigger className="h-12 border-[#D6E4F5] text-gray-900">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="male">Male</SelectItem>
                        <SelectItem value="female">Female</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label className="text-[15px] font-semibold text-[#1B3E6F]">Height (Feet)</Label>
                    <Input type="number" value={feet} onChange={(e) => setFeet(e.target.value)} className="h-12 text-gray-900 border-[#D6E4F5]" />
                  </div>
                  <div className="space-y-2">
                    <Label className="text-[15px] font-semibold text-[#1B3E6F]">Height (Inches)</Label>
                    <Input type="number" value={inches} onChange={(e) => setInches(e.target.value)} className="h-12 text-gray-900 border-[#D6E4F5]" />
                  </div>
                  <div className="space-y-2">
                    <Label className="text-[15px] font-semibold text-[#1B3E6F]">Weight (lbs)</Label>
                    <Input type="number" value={weight} onChange={(e) => setWeight(e.target.value)} className="h-12 text-gray-900 border-[#D6E4F5]" />
                  </div>
                  <div className="space-y-2">
                    <Label className="text-[15px] font-semibold text-[#1B3E6F]">Activity Level</Label>
                    <Select value={activity} onValueChange={setActivity}>
                      <SelectTrigger className="h-12 border-[#D6E4F5] text-gray-900">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="1.2">Sedentary (Little to no exercise)</SelectItem>
                        <SelectItem value="1.375">Lightly active (Light exercise 1-3 days/week)</SelectItem>
                        <SelectItem value="1.55">Moderately active (Moderate exercise 3-5 days/week)</SelectItem>
                        <SelectItem value="1.725">Very active (Hard exercise 6-7 days/week)</SelectItem>
                        <SelectItem value="1.9">Extra active (Very hard exercise & physical job)</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <Button onClick={calculateCalories} className="w-full btn-primary h-14 text-lg font-bold">
                  Calculate Macros
                </Button>

                {result && (
                  <div className="mt-8 grid grid-cols-1 sm:grid-cols-3 gap-4">
                    <div className="bg-white border border-[#D6E4F5] rounded-xl p-6 text-center shadow-sm">
                      <div className="text-sm font-bold text-[#5285C9] uppercase tracking-wide mb-2">Weight Loss</div>
                      <div className="text-3xl font-extrabold text-[#1B3E6F]">{result.loss}</div>
                      <div className="text-xs text-[#5285C9] mt-1">kcal/day</div>
                    </div>
                    <div className="bg-primary text-white rounded-xl p-6 text-center shadow-md scale-105">
                      <div className="text-sm font-bold text-white/80 uppercase tracking-wide mb-2">Maintenance</div>
                      <div className="text-4xl font-extrabold">{result.maintenance}</div>
                      <div className="text-xs text-white/80 mt-1">kcal/day</div>
                    </div>
                    <div className="bg-white border border-[#D6E4F5] rounded-xl p-6 text-center shadow-sm">
                      <div className="text-sm font-bold text-[#5285C9] uppercase tracking-wide mb-2">Weight Gain</div>
                      <div className="text-3xl font-extrabold text-[#1B3E6F]">{result.gain}</div>
                      <div className="text-xs text-[#5285C9] mt-1">kcal/day</div>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </main>

        <Footer />
      </div>
    </>
  );
}

export default CalorieCalculatorPage;
