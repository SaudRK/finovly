
import React from 'react';
import { Link } from 'react-router-dom';
import { Clock, Calendar, ChevronRight } from 'lucide-react';
import CategoryTag from './CategoryTag.jsx';

function BlogCard({ post }) {
  return (
    <Link to={`/blog/${post.id}`} className="block group h-full">
      <div className="bg-white border border-[#D6E4F5] rounded-xl overflow-hidden shadow-sm hover:shadow-md transition-all duration-300 hover:-translate-y-1 flex flex-col h-full">
        <div className="relative h-48 overflow-hidden">
          <img 
            src={post.featuredImage} 
            alt={post.title} 
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
          />
          <div className="absolute top-4 left-4">
            <CategoryTag category={post.category} />
          </div>
        </div>
        <div className="p-6 flex flex-col flex-1">
          <h3 className="text-xl font-bold text-[#1B3E6F] mb-3 group-hover:text-[#3260A8] transition-colors line-clamp-2 leading-snug">
            {post.title}
          </h3>
          <p className="text-[#5285C9] text-[15px] line-clamp-3 mb-4 flex-1">
            {post.excerpt}
          </p>
          
          <div className="flex items-center text-[#3260A8] font-semibold text-sm mb-5 group-hover:text-[#1B3E6F] transition-colors">
            Read more <ChevronRight className="w-4 h-4 ml-1" />
          </div>

          <div className="flex items-center justify-between text-sm text-[#8FA8C8] font-medium mt-auto pt-4 border-t border-[#D6E4F5]">
            <div className="flex items-center gap-1.5">
              <Calendar className="w-4 h-4" />
              <span>{new Date(post.datePublished).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}</span>
            </div>
            <div className="flex items-center gap-1.5">
              <Clock className="w-4 h-4" />
              <span>{post.readTime}</span>
            </div>
          </div>
        </div>
      </div>
    </Link>
  );
}

export default BlogCard;
