
import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import GrowthChart from '@/components/GrowthChart.jsx';
import { Calculator, TrendingUp, DollarSign, Percent } from 'lucide-react';

function CompoundInterestCalculator() {
  const [initialInvestment, setInitialInvestment] = useState('');
  const [monthlyContribution, setMonthlyContribution] = useState('');
  const [annualRate, setAnnualRate] = useState('');
  const [years, setYears] = useState('');
  const [compoundingFrequency, setCompoundingFrequency] = useState('12');
  const [results, setResults] = useState(null);
  const [chartData, setChartData] = useState([]);

  const calculateCompoundInterest = () => {
    const P = parseFloat(initialInvestment) || 0;
    const PMT = parseFloat(monthlyContribution) || 0;
    const r = (parseFloat(annualRate) || 0) / 100;
    const n = parseInt(compoundingFrequency);
    const t = parseFloat(years) || 0;

    if (P < 0 || PMT < 0 || r < 0 || t <= 0) {
      return;
    }

    const yearlyData = [];
    
    for (let year = 0; year <= t; year++) {
      let futureValue;
      
      if (r === 0) {
        futureValue = P + (PMT * 12 * year);
      } else {
        const compoundGrowth = P * Math.pow(1 + r / n, n * year);
        const contributionGrowth = PMT * ((Math.pow(1 + r / n, n * year) - 1) / (r / n));
        futureValue = compoundGrowth + contributionGrowth;
      }

      yearlyData.push({
        year: year,
        value: futureValue
      });
    }

    const finalValue = yearlyData[yearlyData.length - 1].value;
    const totalInvested = P + (PMT * 12 * t);
    const totalInterest = finalValue - totalInvested;

    setResults({
      futureValue: finalValue,
      totalInterest: totalInterest,
      totalInvested: totalInvested
    });
    setChartData(yearlyData);
  };

  const handleReset = () => {
    setInitialInvestment('');
    setMonthlyContribution('');
    setAnnualRate('');
    setYears('');
    setCompoundingFrequency('12');
    setResults(null);
    setChartData([]);
  };

  const formatCurrency = (value) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    }).format(value);
  };

  return (
    <div className="w-full max-w-6xl mx-auto">
      <Card className="shadow-lg">
        <CardHeader>
          <CardTitle className="text-2xl font-semibold flex items-center gap-2">
            <Calculator className="w-6 h-6 text-primary" />
            Compound Interest Calculator
          </CardTitle>
          <CardDescription>
            Enter your investment details to see how your money can grow over time
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <div>
                <Label htmlFor="initial" className="text-sm font-medium">Initial Investment ($)</Label>
                <div className="relative mt-1">
                  <DollarSign className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                  <Input
                    id="initial"
                    type="number"
                    placeholder="10000"
                    value={initialInvestment}
                    onChange={(e) => setInitialInvestment(e.target.value)}
                    className="pl-9 text-gray-900"
                    min="0"
                  />
                </div>
              </div>

              <div>
                <Label htmlFor="monthly" className="text-sm font-medium">Monthly Contribution ($)</Label>
                <div className="relative mt-1">
                  <DollarSign className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                  <Input
                    id="monthly"
                    type="number"
                    placeholder="500"
                    value={monthlyContribution}
                    onChange={(e) => setMonthlyContribution(e.target.value)}
                    className="pl-9 text-gray-900"
                    min="0"
                  />
                </div>
              </div>

              <div>
                <Label htmlFor="rate" className="text-sm font-medium">Annual Interest Rate (%)</Label>
                <div className="relative mt-1">
                  <Percent className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                  <Input
                    id="rate"
                    type="number"
                    placeholder="7"
                    value={annualRate}
                    onChange={(e) => setAnnualRate(e.target.value)}
                    className="pl-9 text-gray-900"
                    min="0"
                    step="0.1"
                  />
                </div>
              </div>
            </div>

            <div className="space-y-4">
              <div>
                <Label htmlFor="years" className="text-sm font-medium">Time Period (Years)</Label>
                <div className="relative mt-1">
                  <TrendingUp className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                  <Input
                    id="years"
                    type="number"
                    placeholder="20"
                    value={years}
                    onChange={(e) => setYears(e.target.value)}
                    className="pl-9 text-gray-900"
                    min="1"
                  />
                </div>
              </div>

              <div>
                <Label htmlFor="frequency" className="text-sm font-medium">Compounding Frequency</Label>
                <Select value={compoundingFrequency} onValueChange={setCompoundingFrequency}>
                  <SelectTrigger id="frequency" className="mt-1">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="12">Monthly</SelectItem>
                    <SelectItem value="4">Quarterly</SelectItem>
                    <SelectItem value="1">Annually</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="flex gap-3 pt-4">
                <Button 
                  onClick={calculateCompoundInterest} 
                  className="flex-1 bg-primary text-primary-foreground hover:bg-primary/90 transition-all duration-200 active:scale-[0.98]"
                >
                  Calculate
                </Button>
                <Button 
                  onClick={handleReset} 
                  variant="outline"
                  className="transition-all duration-200 active:scale-[0.98]"
                >
                  Reset
                </Button>
              </div>
            </div>
          </div>

          {results && (
            <div className="mt-8 space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <Card className="bg-primary text-primary-foreground">
                  <CardHeader className="pb-3">
                    <CardDescription className="text-primary-foreground/80">Future Value</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <p className="text-3xl font-bold">{formatCurrency(results.futureValue)}</p>
                  </CardContent>
                </Card>

                <Card className="bg-accent text-accent-foreground">
                  <CardHeader className="pb-3">
                    <CardDescription className="text-accent-foreground/80">Total Interest Earned</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <p className="text-3xl font-bold">{formatCurrency(results.totalInterest)}</p>
                  </CardContent>
                </Card>

                <Card className="bg-muted text-muted-foreground">
                  <CardHeader className="pb-3">
                    <CardDescription className="text-muted-foreground/80">Total Invested</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <p className="text-3xl font-bold text-foreground">{formatCurrency(results.totalInvested)}</p>
                  </CardContent>
                </Card>
              </div>

              <div>
                <h3 className="text-xl font-semibold mb-2">Growth Trajectory</h3>
                <GrowthChart data={chartData} />
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

export default CompoundInterestCalculator;
