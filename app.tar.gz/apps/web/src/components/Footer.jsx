
import React from 'react';
import { Link } from 'react-router-dom';

function Footer() {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-[#1B3E6F] text-white mt-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-12">
          <div className="lg:col-span-2">
            <Link to="/" className="inline-block mb-6">
              <img 
                src="https://horizons-cdn.hostinger.com/ddb1bf61-ad7f-403c-98d4-7d62beea60b8/61f6fa1a7da666cb7c29b5ba0430e28b.png" 
                alt="Finovly" 
                className="h-10 w-auto"
              />
            </Link>
            <p className="text-[#D6E4F5] text-[15px] max-w-sm leading-relaxed mb-6">
              Empowering Americans to make confident, unbiased financial decisions with free tools and expert guides.
            </p>
          </div>

          <div>
            <h3 className="font-bold text-white mb-5 uppercase tracking-wider text-sm">Calculators</h3>
            <ul className="space-y-3">
              <li><Link to="/calculators" className="text-[#D6E4F5] hover:text-white transition-colors text-[15px]">Compound Interest</Link></li>
              <li><Link to="/calculators" className="text-[#D6E4F5] hover:text-white transition-colors text-[15px]">Mortgage Payment</Link></li>
              <li><Link to="/calculators" className="text-[#D6E4F5] hover:text-white transition-colors text-[15px]">Auto Loan</Link></li>
            </ul>
          </div>

          <div>
            <h3 className="font-bold text-white mb-5 uppercase tracking-wider text-sm">Legal</h3>
            <ul className="space-y-3">
              <li><Link to="/about" className="text-[#D6E4F5] hover:text-white transition-colors text-[15px]">About Us</Link></li>
              <li><Link to="/privacy" className="text-[#D6E4F5] hover:text-white transition-colors text-[15px]">Privacy Policy</Link></li>
              <li><Link to="/terms" className="text-[#D6E4F5] hover:text-white transition-colors text-[15px]">Terms of Service</Link></li>
            </ul>
          </div>
        </div>

        <div className="border-t border-white/10 pt-8 flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-[#8FA8C8] text-[14px]">
            © {currentYear} Finovly. All rights reserved. Not financial advice.
          </p>
        </div>
      </div>
    </footer>
  );
}

export default Footer;
