
import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Menu, X, ChevronDown } from 'lucide-react';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

function Header() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [mobileCalculatorsOpen, setMobileCalculatorsOpen] = useState(false);
  const location = useLocation();

  const calculators = [
    { name: 'Compound Interest', path: '/compound-interest-calculator' },
    { name: 'Mortgage Calculator', path: '/mortgage-calculator' },
    { name: 'Loan Comparison', path: '/loan-comparison-calculator' },
    { name: 'BMI Calculator', path: '/bmi-calculator' },
    { name: 'Calorie Calculator', path: '/calorie-calculator' },
    { name: 'Salary Tax', path: '/salary-tax-calculator' },
  ];

  const navLinks = [
    { name: 'Learn', path: '/blog' },
    { name: 'About', path: '/about' },
  ];

  const isActive = (path) => location.pathname.startsWith(path) && path !== '/' || (path === '/' && location.pathname === '/');
  const isCalculatorActive = calculators.some(calc => location.pathname === calc.path) || location.pathname === '/calculators';

  return (
    <header className="sticky top-0 z-50 w-full bg-[#1B3E6F] border-b border-white/10 shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          <Link to="/" className="flex items-center">
            <img 
              src="https://horizons-cdn.hostinger.com/ddb1bf61-ad7f-403c-98d4-7d62beea60b8/c52d3817719d3ef4d9d7bc23f603ed66.png" 
              alt="Finovly Logo" 
              className="h-10 w-auto"
            />
          </Link>

          <nav className="hidden md:flex items-center gap-8">
            <DropdownMenu>
              <DropdownMenuTrigger className={`flex items-center gap-1 text-[15px] font-medium transition-colors outline-none ${
                isCalculatorActive ? 'text-white' : 'text-[#D6E4F5] hover:text-white'
              }`}>
                Calculators <ChevronDown className="w-4 h-4 opacity-70" />
              </DropdownMenuTrigger>
              <DropdownMenuContent 
                align="start" 
                className="w-56 bg-[#1B3E6F] border-white/10 text-white shadow-xl animate-in fade-in-80 zoom-in-95"
              >
                <DropdownMenuItem asChild className="focus:bg-white/10 focus:text-white cursor-pointer">
                  <Link to="/calculators" className="w-full font-semibold border-b border-white/10 mb-1 pb-2">
                    All Calculators
                  </Link>
                </DropdownMenuItem>
                {calculators.map((calc) => (
                  <DropdownMenuItem key={calc.path} asChild className="focus:bg-white/10 focus:text-white cursor-pointer">
                    <Link to={calc.path} className="w-full">
                      {calc.name}
                    </Link>
                  </DropdownMenuItem>
                ))}
              </DropdownMenuContent>
            </DropdownMenu>

            {navLinks.map((link) => (
              <Link
                key={link.path}
                to={link.path}
                className={`text-[15px] font-medium transition-colors ${
                  isActive(link.path) 
                    ? 'text-white' 
                    : 'text-[#D6E4F5] hover:text-white'
                }`}
              >
                {link.name}
              </Link>
            ))}
          </nav>

          <button
            className="md:hidden p-2 text-[#D6E4F5] hover:text-white hover:bg-white/10 rounded-md transition-colors"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            aria-label="Toggle menu"
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>

        {mobileMenuOpen && (
          <nav className="md:hidden py-4 border-t border-white/10 bg-[#1B3E6F] animate-in slide-in-from-top-2">
            <div className="flex flex-col gap-1">
              <button
                onClick={() => setMobileCalculatorsOpen(!mobileCalculatorsOpen)}
                className={`flex items-center justify-between px-4 py-3 rounded-md text-[15px] font-medium transition-colors w-full text-left ${
                  isCalculatorActive ? 'bg-white/10 text-white' : 'text-[#D6E4F5] hover:bg-white/5 hover:text-white'
                }`}
              >
                Calculators
                <ChevronDown className={`w-4 h-4 transition-transform ${mobileCalculatorsOpen ? 'rotate-180' : ''}`} />
              </button>
              
              {mobileCalculatorsOpen && (
                <div className="flex flex-col gap-1 pl-8 pr-4 py-2 bg-black/10 rounded-md mx-2 mb-2">
                  <Link
                    to="/calculators"
                    onClick={() => setMobileMenuOpen(false)}
                    className="py-2 text-sm font-semibold text-white border-b border-white/10 mb-1"
                  >
                    All Calculators
                  </Link>
                  {calculators.map((calc) => (
                    <Link
                      key={calc.path}
                      to={calc.path}
                      onClick={() => setMobileMenuOpen(false)}
                      className={`py-2 text-sm transition-colors ${
                        location.pathname === calc.path ? 'text-white font-medium' : 'text-[#D6E4F5] hover:text-white'
                      }`}
                    >
                      {calc.name}
                    </Link>
                  ))}
                </div>
              )}

              {navLinks.map((link) => (
                <Link
                  key={link.path}
                  to={link.path}
                  onClick={() => setMobileMenuOpen(false)}
                  className={`px-4 py-3 rounded-md text-[15px] font-medium transition-colors ${
                    isActive(link.path) 
                      ? 'bg-white/10 text-white' 
                      : 'text-[#D6E4F5] hover:bg-white/5 hover:text-white'
                  }`}
                >
                  {link.name}
                </Link>
              ))}
            </div>
          </nav>
        )}
      </div>
    </header>
  );
}

export default Header;
