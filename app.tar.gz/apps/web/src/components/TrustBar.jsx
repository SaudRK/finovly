
import React from 'react';
import { Calculator, ShieldCheck, RefreshCw } from 'lucide-react';

function TrustBar() {
  const stats = [
    { icon: Calculator, text: '2M+ Calculations Run' },
    { icon: ShieldCheck, text: '500+ Products Reviewed' },
    { icon: RefreshCw, text: 'Updated Weekly' },
  ];

  return (
    <div className="w-full max-w-5xl mx-auto px-4 relative z-10 -mt-10 mb-16">
      <div className="bg-[#1B3E6F] px-8 py-6 flex flex-col md:flex-row justify-between items-center gap-6 rounded-lg shadow-lg">
        {stats.map((stat, index) => (
          <div key={index} className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-white/15 flex items-center justify-center">
              <stat.icon className="w-5 h-5 text-white" />
            </div>
            <span className="font-medium text-white">{stat.text}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

export default TrustBar;
