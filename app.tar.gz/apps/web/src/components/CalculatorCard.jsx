
import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight } from 'lucide-react';

function CalculatorCard({ icon: Icon, title, description, link = "#" }) {
  return (
    <Link to={link} className="block group h-full">
      <div className="card-white h-full p-6 flex flex-col items-start transition-all duration-300">
        <div className="w-12 h-12 bg-[#F0F5FC] rounded-lg flex items-center justify-center mb-5 group-hover:bg-[#D6E4F5] transition-colors">
          <Icon className="w-6 h-6 text-[#3260A8]" />
        </div>
        <h3 className="text-lg font-bold text-[#1B3E6F] mb-2">{title}</h3>
        <p className="text-[#5285C9] text-[15px] flex-1 mb-6 leading-relaxed">
          {description}
        </p>
        <button className="btn-primary px-5 py-2.5 text-sm w-full flex items-center justify-center gap-2 mt-auto">
          Use Tool <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
        </button>
      </div>
    </Link>
  );
}

export default CalculatorCard;
