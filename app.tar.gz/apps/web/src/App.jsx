
import React from 'react';
import { Route, Routes, BrowserRouter as Router } from 'react-router-dom';
import ScrollToTop from './components/ScrollToTop.jsx';
import HomePage from './pages/HomePage.jsx';
import CalculatorsPage from './pages/CalculatorsPage.jsx';
import CompoundInterestCalculatorPage from './pages/CompoundInterestCalculatorPage.jsx';
import MortgageCalculatorPage from './pages/MortgageCalculatorPage.jsx';
import LoanComparisonCalculatorPage from './pages/LoanComparisonCalculatorPage.jsx';
import BMICalculatorPage from './pages/BMICalculatorPage.jsx';
import CalorieCalculatorPage from './pages/CalorieCalculatorPage.jsx';
import SalaryTaxCalculatorPage from './pages/SalaryTaxCalculatorPage.jsx';
import ComparePage from './pages/ComparePage.jsx';
import BlogPage from './pages/BlogPage.jsx';
import BlogPostPage from './pages/BlogPostPage.jsx';
import AboutPage from './pages/AboutPage.jsx';
import PrivacyPage from './pages/PrivacyPage.jsx';
import TermsOfServicePage from './pages/TermsOfServicePage.jsx';

function App() {
  return (
    <Router>
      <ScrollToTop />
      <Routes>
        <Route path="/" element={<HomePage />} />
        
        {/* Hub Page */}
        <Route path="/calculators" element={<CalculatorsPage />} />
        
        {/* Dedicated Calculator Pages */}
        <Route path="/compound-interest-calculator" element={<CompoundInterestCalculatorPage />} />
        <Route path="/mortgage-calculator" element={<MortgageCalculatorPage />} />
        <Route path="/loan-comparison-calculator" element={<LoanComparisonCalculatorPage />} />
        <Route path="/bmi-calculator" element={<BMICalculatorPage />} />
        <Route path="/calorie-calculator" element={<CalorieCalculatorPage />} />
        <Route path="/salary-tax-calculator" element={<SalaryTaxCalculatorPage />} />

        <Route path="/compare" element={<ComparePage />} />
        
        {/* Blog Routes */}
        <Route path="/blog" element={<BlogPage />} />
        <Route path="/blog/:id" element={<BlogPostPage />} />
        
        {/* Legal & Info Routes */}
        <Route path="/about" element={<AboutPage />} />
        <Route path="/privacy" element={<PrivacyPage />} />
        <Route path="/terms" element={<TermsOfServicePage />} />
      </Routes>
    </Router>
  );
}

export default App;
